<?php
  include ('../class/Connection.class.php');
  include ('../class/WebserviceDAO.class.php');

  $excluir = new WebserviceDAO();


  $delete = $excluir->doDelete($_GET['codigo']);

    if($delete == true) {
      echo "<script>window.location = '../view/homeDashboard.php?p=8'</script>";
    }
