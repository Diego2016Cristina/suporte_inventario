<?php
  # INICIANDO A SESSION;
  session_start();

  include ('../class/Connection.class.php');
  include ('../class/WebserviceDAO.class.php');

  $cadastrar = new WebserviceDAO();

  $dadoForm = array(
    'codigo'    => trim(strip_tags($_POST['codigo'])),
    'descricao' => trim(strip_tags($_POST['descricao']))
  );

    $consulta = $cadastrar->unico($dadoForm['codigo']);
    // caso o login escolhido já exista no banco retorna erro
    if($consulta == true) {// Nesse caso já existe um usuário cadastrado com as informações exigidas;
      // Usada para manter os dados nos campos input evitando assim que o usuário tenha que escrever tudo novamente;
      $_SESSION['codigo']    = $dadoForm['codigo'];

      $_SESSION['msn'] = "<div>Código já está cadastrado.</div>";
      header("Location:../view/homeDashboard.php?p=8");
    // caso não haja login parecido, inclui métoro de inserção de dados no banco de dados
    } else {
      $insere = $cadastrar->cadastra($dadoForm['codigo'], $dadoForm['descricao']);
      // caso o usuario seja cadastrado, exibir mensagem de sucesso
      if($insere == true) {

          $_SESSION['msn'] = "<div>Cadastrado com sucesso.</div>";
          header("Location:../view/homeDashboard.php?p=8");
        }
      }
