<?php
  # INICIANDO A SESSION;
  session_start();

  include ('../class/Connection.class.php');
  include ('../class/UsuarioDAO.class.php');

  $cadastrar = new UsuarioDAO();

  $matricula = trim(strip_tags($_POST['matricula']));
  $nome = trim(strip_tags($_POST['nome']));
  $email = trim(strip_tags($_POST['email']));
  $apelido = trim(strip_tags($_POST['apelido'])); // atribui login à variavel, com funções contra sql inject
  $senha = trim(strip_tags($_POST['senha'])); // atribui login à variavel, com funções contra sql inject
  $repetirSenha = trim(strip_tags($_POST['repetirSenha'])); // atribui login à variavel, com funções contra sql inject
  $perfil = trim(strip_tags($_POST['perfil']));

  // confere se as senhas são iguais
  if($senha === $repetirSenha) {
    $consulta = $cadastrar->unico($apelido, $matricula);
    // caso o login escolhido já exista no banco retorna erro
    if($consulta == true) {// Nesse caso já existe um usuário cadastrado com as informações exigidas;
      // Usada para manter os dados nos campos input evitando assim que o usuário tenha que escrever tudo novamente;
      $_SESSION['matricula'] = $matricula;
      $_SESSION['nome']      = $nome;
      $_SESSION['email']     = $email;
      $_SESSION['apelido']   = $apelido;
      $_SESSION['perfil']    = $perfil;
      $_SESSION['msn'] = "<div class='alert alert-warning' role='alert'>Já existe um usuário cadastrado com essas informações.</div>";
      header("Location:../view/homeDashboard.php?p=1");
    // caso não haja login parecido, inclui métoro de inserção de dados no banco de dados
    } else {
      $senhaMD5 = md5($senha);
      $insere = $cadastrar->cadastra($matricula, $nome, $email, $apelido, $senhaMD5);
      // caso o usuario seja cadastrado, exibir mensagem de sucesso
      if($insere == true) {
        $buscar = $cadastrar->doConsultaGrupo($perfil);

        if($buscar) {
          $inserindo = $cadastrar->doCadGrupo($matricula, $buscar);
          unset($_SESSION['matricula']);
          unset($_SESSION['apelido']);
          unset($_SESSION['nome']);
          unset($_SESSION['email']);
          $_SESSION['msn'] = "<div class='alert alert-success' role='alert'>Usuário cadastrado com sucesso.  (•◡•) /</div>";
          header("Location:../view/homeDashboard.php?p=2");
        }
      }
    }

  } else {
    $_SESSION['matricula'] = $matricula;
    $_SESSION['nome'] = $nome;
    $_SESSION['email'] = $email;
    $_SESSION['apelido'] = $apelido;
    $_SESSION['msn'] = "<div class='alert alert-danger' role='alert'>A confirmação de senha não confere(Elas precisam ser iguais).</div>";

  }
