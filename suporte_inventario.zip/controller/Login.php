<?php
  # INICIANDO A SESSION;
  session_start();

  include ('../class/Connection.class.php');
  include ('../class/UsuarioDAO.class.php');

  $editar = new UsuarioDAO();

  $apelido = addslashes($_POST['apelido']);
  $senha = addslashes($_POST['senha']);

  $user = $editar->login($apelido, md5($senha));

  if($user == true) {
    $_SESSION['apelidoUsuario'] = $apelido;
    $busca = $editar->doDadosUsuarios($apelido);
    $dadosUsuario = array(
      'matricula' => $busca['matricula'],
      'nome'      => $busca['nome'],
      'email'     => $busca['email'],
      'dt_criacao'=> $busca['dt_criacao'],
      'perfil'    => $busca['perfil'],
      'apelido'   => $busca['apelido']
    );

    $_SESSION['dados'] = $dadosUsuario;

    header('location: ../view/homeDashboard.php?p=5');
  } else {
    $_SESSION['apelido'] = $apelido;
    header("Location:../view/login.php?erro=senha");
  }
