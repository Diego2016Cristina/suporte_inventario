<?php
  include ('../class/Connection.class.php');
  include ('../class/UsuarioDAO.class.php');

  $excluir = new UsuarioDAO();


  $delete = $excluir->doDelete($_GET['matricula']);

    if($delete == true) {
      echo "<script>window.location = '../view/homeDashboard.php?p=2'</script>";
    }
