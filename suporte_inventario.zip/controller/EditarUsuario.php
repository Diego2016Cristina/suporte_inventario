<?php
  # INICIANDO A SESSION;
  session_start();
  include ('../class/Connection.class.php');
  include ('../class/UsuarioDAO.class.php');

  $editar = new UsuarioDAO();

  $dadosForm = array(
    'matricula' => $matricula = trim(strip_tags($_POST['matricula'])),
    'nome'      => $nome      = trim(strip_tags($_POST['nome'])),
    'email'     => $email     = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL),
    'apelido'   => $apelido   = trim(strip_tags($_POST['apelido'])),
    'perfil'    => $_POST['perfil'],
    'senha'     => $senha     = trim(strip_tags($_POST['senha'])),
    'reSenha'   => $senha     = trim(strip_tags($_POST['repetirSenha'])),
    'dt_modificacao' => date('Y-m-d H:m:s')
  );

  // Convertendo a opção do perfil em um numeral;
  if($dadosForm['perfil'] == 'users') {
    $dadosForm['perfil'] = 1;
  } else if($dadosForm['perfil'] == 'sup') {
    $dadosForm['perfil'] = 2;
  }else if($dadosForm['perfil'] == 'adm') {
    $dadosForm['perfil'] = 3;
  }else if($dadosForm['perfil'] == 'adm_dev') {
    $dadosForm['perfil'] = 4;
  }

  if($dadosForm['reSenha'] == "") {
    $insere = $editar->doEditar($dadosForm['matricula'], $dadosForm['nome'], $dadosForm['email'], $dadosForm['apelido'], $dadosForm['perfil'], md5($dadosForm['senha']), $dadosForm['dt_modificacao'], $dadosForm['perfil']);
    if($insere == true) {
      header("Location:../view/homeDashboard.php?p=4&matricula=".$dadosForm['matricula']."&m=v");
    }
  }else if($dadosForm['reSenha'] != "") {
    if($dadosForm['senha'] != $dadosForm['reSenha']) {
      $insere = $editar->doEditar($dadosForm['matricula'], $dadosForm['nome'], $dadosForm['email'], $dadosForm['apelido'], $dadosForm['perfil'], md5($dadosForm['senha']), $dadosForm['dt_modificacao'], $dadosForm['perfil']);
      if($insere == true) {
        header("Location:../view/homeDashboard.php?p=4&matricula=".$dadosForm['matricula']."&m=s");
      }
    } else {
      $insere = $editar->doEditar($dadosForm['matricula'], $dadosForm['nome'], $dadosForm['email'], $dadosForm['apelido'], $dadosForm['perfil'], md5($dadosForm['senha']), $dadosForm['dt_modificacao'], $dadosForm['perfil']);
      if($insere == true) {
        header("Location:../view/homeDashboard.php?p=4&matricula=".$dadosForm['matricula']."&m=e");
      }
    }
  }
