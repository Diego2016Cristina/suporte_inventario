<?php
  # INICIANDO A SESSION;
  session_start();
  include ('../class/Connection.class.php');
  include ('../class/WebserviceDAO.class.php');

  $editar = new WebserviceDAO();

  $dadosForm = array(
    'codigo'         => $codigo    = trim(strip_tags($_POST['codigo'])),
    'descricao'      => $descricao = trim(strip_tags($_POST['descricao'])),
    'perfil_ws'      => $apelido   = trim(strip_tags($_POST['perfil_ws'])),
    'dt_modificacao' => date('Y-m-d H:m:s')
  );

  if($dadosForm['codigo'] != "") {
    $insere = $editar->doEditar($dadosForm['codigo'], $dadosForm['descricao'], $dadosForm['perfil_ws'], $dadosForm['dt_modificacao']);
    if($insere == true) {
      header("Location:../view/homeDashboard.php?p=9&codigo=".$dadosForm['codigo']."&m=v");
    }
  }
