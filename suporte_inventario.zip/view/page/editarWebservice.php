<?php

  include ('../class/Connection.class.php');
  include ('../class/WebserviceDAO.class.php');
  unset($_SESSION['msn']);
  $WebSelecionado = new WebserviceDAO();

  $dadosWebservice = $WebSelecionado->unico(isset($_GET['codigo'])?$_GET['codigo']:'');
  $dados = $WebSelecionado->doBuscaUnica(isset($_GET['codigo'])?$_GET['codigo']:'');

?>
<script type="text/javascript">//Ainda não está funcional, verificar isso + tarde.
    setTimeout(function() {
    $("#msn").fadeOut().empty();
  }, 4000);
</script>
<div class="box-body" style="width: 96%; margin: 0 auto; border: 1px solid #cccccc">
    <form action="../controller/EditarWebservice.php" method="POST">
        <div id="msn">
          <!-- if() -->
        </div>
        <div class="row">
          <div class="col-sm-4">
            <label>Código</label>
              <div class="form-group has-feedback">
                <input type="text" class="form-control" name="codigo" id="aux" placeholder="Código" value="<?= $dados[0]; ?>">
                <span class="glyphicon glyphicon-list-alt form-control-feedback"></span>
              </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-6">
            <label>Descricao</label>
            <div class="form-group has-feedback">
              <input type="text" class="form-control" name="descricao" value="<?= $dados[1] ?>" placeholder="Nome completo" required>
              <span class="glyphicon glyphicon-user form-control-feedback"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-4">
            <label>Situação</label>
            <div class="form-group has-feedback">
                <select class="form-control" id="perfil" name="perfil_ws">
                  <?php switch ($dados[3]) {
                    case 1:
                      echo "<option value='1' selected>Ativo</option>
                            <option value='0'>Inativo</option>";
                      break;
                    case 0:
                      echo "<option value='1' selected>Ativo</option>
                            <option value='0' selected>Inativo</option>";
                      break;
                    default:
                      // code...
                      break;
                  } ?>
                </select>
            </div>
          </div>
        </div>
      <div class="row">
        <div class="col-xs-4">
          <button type="submit" class="btn btn-primary btn-block btn-flat">Editar</button>
        </div>
      </div>
    </form>
</div>
