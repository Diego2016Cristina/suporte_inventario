<div class="container-fluid">
  <div class="row">
    <form>
      <div class="col-sm-2">
        <div class="form-group">
          <label for="exampleInputEmail1">Bancada</label>
          <select class="form-control" id="exampleFormControlSelect1">
            <option>Selecione</option>
            <option>1</option>
            <option>2</option>
            <option>3</option>
            <option>4</option>
            <option>5</option>
            <option>6</option>
            <option>7</option>
            <option>8</option>
            <option>9</option>
            <option>10</option>
            <option>11</option>
            <option>12</option>
            <option>13</option>
            <option>14</option>
          </select>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="form-group">
          <label for="exampleInputEmail1">Linha</label>
          <select class="form-control" id="exampleFormControlSelect1">
            <option>Selecione</option>
            <option>#BE11</option>
            <option>#BE12</option>
            <option>#BE13</option>
            <option>#BE14</option>
            <option>#BE15</option>
            <option>#BE16</option>
            <option>#BE17</option>
          </select>
        </div>
      </div>
      <div class="col-sm-3">
        <label>Manter linha?</label>
        <div class="form-check">
          <input type="radio" class="form-check-input" id="materialChecked" name="materialExampleRadios">
          <label class="form-check-label" for="materialChecked">Sim </label>&nbsp;
          <input type="radio" class="form-check-input" id="materialUnchecked" name="materialExampleRadios">
          <label class="form-check-label" for="materialUnchecked">Não </label>&nbsp;
        </div>
      </div>
    </form>
  </div>
  <div class="row">
    <div class="col-sm-4"></div>
    <div class="col-sm-4"></div>
    <div class="col-sm-4">
      <div class="form-group input-group">
      	<span class="input-group-addon"><i class="glyphicon glyphicon-search"></i></span>
      	<input name="consulta" id="txt_consulta" placeholder="Consultar" type="text" class="form-control">
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-sm-12">
      <table class="table table-bordered">
        <thead style="background: #000; color: #fff">
          <tr>
            <th scope="col">#</th>
            <th scope="col">Código</th>
            <th scope="col">Descrição</th>
            <th scope="col">Opção</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">1</th>
            <td>897364855</td>
            <td>Conector HDMI 3.0</td>
            <td><button type="button" class="btn btn-danger btn-sm">Remover</button></td>
          </tr>
          <tr>
            <th scope="row">2</th>
            <td>Jacob</td>
            <td>Thornton</td>
            <td><button type="button" class="btn btn-danger btn-sm">Remover</button></td>
          </tr>
          <tr>
            <th scope="row">3</th>
            <td>Larry</td>
            <td>the Bird</td>
            <td><button type="button" class="btn btn-danger btn-sm">Remover</button></td>
          </tr>
          <tr>
            <th scope="row">4</th>
            <td>Larry</td>
            <td>the Bird</td>
            <td><button type="button" class="btn btn-danger btn-sm">Remover</button></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
  <div class="row">
    <div class="col-sm-4"></div>
    <div class="col-sm-4"></div>
    <div class="col-sm-4">
      <button type="button" class="btn btn-success btn-sm btn-lg btn-block">Adicionar</button>
    </div>
  </div>
</div>
