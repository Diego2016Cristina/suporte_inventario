<script type="text/javascript">//Ainda não está funcional, verificar isso + tarde.
    setTimeout(function() {
    $("#msn").fadeOut().empty();
  }, 5000);
</script>
<div class="box-body" style="width: 96%; margin: 0 auto">
  <div class="row">
    <form action="../controller/Usuario.php" method="POST" id="form1">
      <div class="row">
        <div id="msn">
          <?php echo (isset($_SESSION['msn'])?$_SESSION['msn']:''); ?>
        </div>
        <div class="col-sm-2">
          <label>Matrícula</label>
          <div class="form-group has-feedback">
            <input type="text" class="form-control" name="matricula" placeholder="Matrícula" minlength="5" maxlength="5" value="<?= (isset($_SESSION['matricula'])? $_SESSION['matricula']:'')?>" required>
            <span class="glyphicon glyphicon-list-alt form-control-feedback"></span>
          </div>
        </div>
        <div class="col-sm-6">
          <label>Nome completo</label>
          <div class="form-group has-feedback">
            <input type="text" class="form-control" name="nome" id="nome" value="<?= (isset($_SESSION['nome'])? $_SESSION['nome']:'')?>" placeholder="Nome completo" required>
            <span class="glyphicon glyphicon-user form-control-feedback"></span>
          </div>
        </div>
        <div class="col-sm-4">
          <label>Perfil</label>
          <div class="form-group has-feedback">
            <select class="form-control" name="perfil">
              <option>Selecione</option>
              <?php
                switch ($_SESSION['perfil']) {
                  case 'users':
                    echo "<option value='users' selected>Usuário</option>";
                    echo "<option value='sup'>Usuário Suporte</option>";
                    echo "<option value='adm'>Usuário Administrador</option>";
                    echo "<option value='adm_dev'>Usuário Desenvolvedor</option>";
                    break;
                  case 'sup':
                    echo "<option value='users'>Usuário</option>";
                    echo "<option value='sup' selected>Usuário Suporte</option>";
                    echo "<option value='adm'>Usuário Administrador</option>";
                    echo "<option value='adm_dev'>Usuário Desenvolvedor</option>";
                    break;
                  case 'adm':
                    echo "<option value='users'>Usuário</option>";
                    echo "<option value='sup'>Usuário Suporte</option>";
                    echo "<option value='adm' selected>Usuário Administrador</option>";
                    echo "<option value='adm_dev'>Usuário Desenvolvedor</option>";
                    break;
                  case 'adm_dev':
                    echo "<option value='users'>Usuário</option>";
                    echo "<option value='sup'>Usuário Suporte</option>";
                    echo "<option value='adm'>Usuário Administrador</option>";
                    echo "<option value='adm_dev' selected>Usuário Desenvolvedor</option>";
                    break;
                  default:
                    echo "<option value='users'>Usuário</option>";
                    echo "<option value='sup'>Usuário Suporte</option>";
                    echo "<option value='adm'>Usuário Administrador</option>";
                    echo "<option value='adm_dev'>Usuário Desenvolvedor</option>";
                    break;
                } ?>
            </select>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-8">
          <label>Email</label>
          <div class="form-group has-feedback">
            <input type="email" class="form-control" name="email" id="email" value="<?= (isset($_SESSION['email'])? $_SESSION['email']:'')?>" placeholder="Email">
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
          </div>
        </div>
        <div class="col-sm-4">
          <label>Apelido</label>
          <div class="form-group has-feedback">
            <input type="text" class="form-control" name="apelido" id="apelido" value="<?= (isset($_SESSION['apelido'])? $_SESSION['apelido']:'')?>" placeholder="Apelido" required>
            <span class="glyphicon glyphicon-user form-control-feedback"></span>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-6">
          <label>Senha</label>
          <div class="form-group has-feedback">
            <input type="password" class="form-control" name="senha" placeholder="Senha" required>
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
        </div>
        <div class="col-sm-6">
          <label>Repetir Senha</label>
          <div class="form-group has-feedback">
            <input type="password" class="form-control" name="repetirSenha" placeholder="Repetir senha" required>
            <span class="glyphicon glyphicon-log-in form-control-feedback"></span>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-xs-8">
          <div class="checkbox icheck">
            <!-- Usado para manter o butão fluando a direita -->
          </div>
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" class="btn btn-primary btn-block btn-flat">Cadastrar</button>
        </div>
        <!-- /.col -->
      </div>
    </form>
    <!-- /.col sss-->
  </div>
  <!-- /.row -->
</div>
<?php
  unset($_SESSION['msnCadTooling']);
?>
