<style>
  .bodysearch {
    position: relative;
    top: -5px;
    float: right;
  }
  .bodyCad {
    position: absolute;
    top: -5px;
    left: 120px;
    float: right;
  }
</style>
<?php
  include ('../class/Connection.class.php');
  include ('../class/WebserviceDAO.class.php');

  #Logica do campo pesquisar
  if(!isset($_POST['field_search'])) {
    $pesquisar = "";
  } else {
    $pesquisar = $_POST['field_search'];
  }

  $collectionObj = new WebserviceDAO();

  $itens_por_pagina = 5;
  $pagina = (isset($_GET['pagina'])?intval($_GET['pagina']):0);

  $sql_code = $collectionObj->doListarWeb($pesquisar, $pagina, $itens_por_pagina);
  $tooling = mysqli_fetch_row($sql_code);
  $num = $collectionObj->doNumRows($pesquisar);

  $num_pagina = ceil($num->num_rows/$itens_por_pagina);

?>
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-4">
      <label>Mostrar</label>
      <select>
        <option>10</option>
        <option>20</option>
        <option>30</option>
        <option>40</option>
      </select>
      <div class="bodyCad">
        <button class="btn btn-success btn-sm" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus" aria-hidden="true"></i> Tooling</button>
      </div>
    </div>
    <div class="col-sm-4">
      <div id="msn">
        <?php echo (isset($_SESSION['msn'])?$_SESSION['msn']:''); ?>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="bodysearch">
        <form action="" method="post">
          <i class="fa fa-search" aria-hidden="true"></i>
          <input type="text" name="field_search" placeholder="Busca somente pelo código">
          <input type="submit" name="btn_search" value="Buscar">
        </form>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-lg-12">
      <?php if($num->num_rows > 0) { ?>
        <table class="table table-bordered table-hover">
          <thead style="background: #333333; color: #fff">
            <tr>
              <td scope="col">Código</td>
              <td scope="col">Descrição</td>
              <td scope="col">Data de Cadastro</td>
              <td scope="col">Situação</td>
              <td scope="col">Opções</td>
            </tr>
          </thead>
          <tbody>
          <?php do{ ?>
              <tr>
                <td scope="row"><?php echo $tooling[0] ?></td>
                <td><?php echo $tooling[1] ?></td>
                <td><?php echo $tooling[2] ?></td>
                <td><?php echo ($tooling[3] == 1)?'Ativo':'Inativo' ?></td>
                <td>
                  <a href="homeDashboard.php?p=9&codigo=<?= $tooling[0] ?>"><button class="btn btn-warning btn-sm"><i class="fa fa-pencil" aria-hidden="true"></i></button></a>
                  <a href="homeDashboard.php?p=7&codigo=<?= $tooling[0] ?>&key=1" onclick="return confirm('Você tem certeza que deseja excluir: <?= $tooling[0] ?>?');"><button class="btn btn-danger btn-sm"><i class="fa fa-trash-o" aria-hidden="true"></i></button></a></td>
              </tr>
            <?php } while($tooling = mysqli_fetch_row($sql_code)); ?>
        </table>
        <nav>
          <ul class="pagination">
            <li class="page-item">
              <a class="page-link" href="../view/homeDashboard.php?p=8&pagina=0" aria-label="Anterior">
                <span aria-hidden="true">&laquo;</span>
                <span class="sr-only">Anterior</span>
              </a>
            </li>
            <?php
              for($i=0; $i<$num_pagina; $i++) {
              $estilo = "";
              if($pagina == $i)
                $estilo = "class=\"active\"";
            ?>
              <li <?php echo $estilo; ?> ><a class="page-link" href="../view/homeDashboard.php?p=8&pagina=<?php echo $i; ?>"><?php echo $i+1; ?></a></li>
            <?php } ?>
            <li class="page-item">
              <a class="page-link" href="../view/homeDashboard.php?p=8&pagina=<?php echo $num_pagina-1; ?>" aria-label="Próximo">
                <span aria-hidden="true">&raquo;</span>
                <span class="sr-only">Próximo</span>
              </a>
            </li>
          </ul>
        </nav>
      <?php } ?>
    </div>
  </div>
</div>
