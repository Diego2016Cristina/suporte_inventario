<style>
  .form-control {
    border: 1px solid #999999;
  }
  #cadWebservice {
    background: rgb(130, 203, 137); padding: 10px; border-radius: 5px;
  }
</style>
<script type="text/javascript">//Ainda não está funcional, verificar isso + tarde.
    setTimeout(function() {
    $("#msn").fadeOut().empty();
  }, 5000);
</script>
<div class="box-body" style="width: 90%; margin: 0 auto">
  <div class="row">
    <div id="msn">
      <?php echo (isset($_SESSION['msn'])?$_SESSION['msn']:''); ?>
    </div>
    <form method="POST" id="cadWebservice" action="../controller/WebserviceCadastro.php">
      <div class="row">
        <div id="msn">
          <?php echo (isset($_SESSION['msnCadTooling'])?$_SESSION['msnCadTooling']:''); ?>
        </div>
        <div class="col-sm-6">
          <label>Código/SAP</label>
          <div class="form-group has-feedback">
            <input type="text" class="form-control" name="codigo" placeholder="Código" minlength="5" maxlength="30" required>
            <span class="glyphicon glyphicon-barcode form-control-feedback"></span>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-6">
          <label>Descrição</label>
          <div class="form-group has-feedback">
            <input type="text" class="form-control" name="descricao" placeholder="Descrição" required>
            <span class="glyphicon glyphicon-edit form-control-feedback"></span>
          </div>
        </div>
      </div>
      <div class="row">
        <!-- /.col -->
        <div class="col-xs-6">
          <button type="submit" name="cadastrar" class="btn btn-primary btn-block btn-flat">Cadastrar</button>
        </div>
        <!-- /.col -->
      </div>
    </form>
    <!-- /.col sss-->
  </div>
  <!-- /.row -->
</div>
<?php unset($_SESSION['msn']); ?>
