<?php
  include ('../class/Connection.class.php');
  include ('../class/UsuarioDAO.class.php');

  $userObj = new UsuarioDAO();

  $itens_por_pagina = 5;
  $pagina = (isset($_GET['pagina'])?intval($_GET['pagina']):0);

  $sql_code = $userObj->doListarUsuario($pagina, $itens_por_pagina);
  $tooling = mysqli_fetch_row($sql_code);
  $num = $userObj->doNumRows();
  $num_pagina = ceil($num->num_rows/$itens_por_pagina);
?>
<div class="container-fluid">
  <div class="row">
    <div class="col-lg-12">
      <?php if($num->num_rows > 0) { ?>
        <table class="table table-bordered table-hover">
          <thead style="background: #333333; color: #fff">
            <tr>
              <td scope="col">Matrícula</td>
              <td scope="col">Nome do colaborador</td>
              <td scope="col">Email</td>
              <td scope="col">Apelido</td>
              <td scope="col">Perfil</td>
              <td scope="col">Data de cadastro</td>
              <td scope="col">Opções</td>
            </tr>
          </thead>
          <tbody>
            <?php do{ ?>
            <tr>
              <td scope="row"><?php echo $tooling[0] ?></td>
              <td><?php echo $tooling[1] ?></td>
              <td><?php echo $tooling[2] ?></td>
              <td><?php echo $tooling[3] ?></td>
              <td><?php echo $tooling[4] ?></td>
              <td><?php echo $tooling[5] ?></td>
              <td>
                <a href="homeDashboard.php?p=4&matricula=<?= $tooling[0] ?>"><button class="btn btn-warning btn-sm"><i class="fa fa-pencil" aria-hidden="true"></i></button></a>
                <a href="homeDashboard.php?p=6&matricula=<?= $tooling[0] ?>&key=1" onclick="return confirm('Você tem certeza que deseja excluir: <?= $tooling[1] ?>?');"><button class="btn btn-danger btn-sm"><i class="fa fa-trash-o" aria-hidden="true"></i></button></a></td>
            </tr>
          <?php } while($tooling = mysqli_fetch_row($sql_code)); ?>
        </table>
        <nav>
          <ul class="pagination">
            <li class="page-item">
              <a class="page-link" href="../view/homeDashboard.php?p=2&pagina=0" aria-label="Anterior">
                <span aria-hidden="true">&laquo;</span>
                <span class="sr-only">Anterior</span>
              </a>
            </li>
            <?php
              for($i=0; $i<$num_pagina; $i++) {
              $estilo = "";
              if($pagina == $i)
                $estilo = "class=\"active\"";
            ?>
              <li <?php echo $estilo; ?> ><a class="page-link" href="../view/homeDashboard.php?p=2&pagina=<?php echo $i; ?>"><?php echo $i+1; ?></a></li>
            <?php } ?>
            <li class="page-item">
              <a class="page-link" href="../view/homeDashboard.php?p=2&pagina=<?php echo $num_pagina-1; ?>" aria-label="Próximo">
                <span aria-hidden="true">&raquo;</span>
                <span class="sr-only">Próximo</span>
              </a>
            </li>
          </ul>
        </nav>
      <?php } ?>
    </div>
  </div>
</div>
