<?php

// include ('../class/Connection.class.php');
// include ('../class/UsuarioDAO.class.php');
unset($_SESSION['msn']);
$usuarioSelecionado = new UsuarioDAO();

$dadosUsuario =
$usuarioSelecionado->doUnico(isset($_GET['matricula'])?$_GET['matricula']:'');

?>
<script type="text/javascript">//Ainda não está funcional, verificar isso + tarde.
    setTimeout(function() {
    $("#msn").fadeOut().empty();
  }, 4000);
</script>
<div class="box-body" style="width: 96%; margin: 0 auto">
  <div class="row">
    <form action="../controller/EditarUsuario.php" method="POST">
      <input type="hidden" name="aux" id="auxPerfil" value="<?= $_SESSION['dados']['perfil'] ?>">
      <input type="hidden" name="keySession" id="keySession" value="<?= (isset($_SESSION['dados']['matricula']))?$_SESSION['dados']['matricula']:'' ?>">
      <input type="hidden" name="keyGet" id="keyGet" value="<?= (isset($_GET['matricula']))?$_GET['matricula']:'' ?>">
      <div class="row">
        <div id="msn">
          <?php switch (isset($_GET['m'])?$_GET['m']:'') {
            case 's':
                echo "<div class='alert alert-danger' role='alert'>As senhas devem ser iguais.</div>";
              break;
              case 'e':
                echo "<div class='alert alert-success' role='alert'>Senha alterada com sucesso.</div>";
              break;
            default:
              // code...
              break;
          } ?>
        </div>
        <div class="col-sm-2">
          <label>Matrícula</label>
            <div class="form-group has-feedback">
              <input type="text" class="form-control" name="matricula" id="aux" placeholder="Matrícula" value="<?= $dadosUsuario[0]; ?>">
              <span class="glyphicon glyphicon-list-alt form-control-feedback"></span>
            </div>
        </div>
        <div class="col-sm-6">
          <label>Nome completo</label>
          <div class="form-group has-feedback">
            <input type="text" class="form-control" name="nome" id="nome" value="<?= $dadosUsuario[1] ?>" placeholder="Nome completo" required>
            <span class="glyphicon glyphicon-user form-control-feedback"></span>
          </div>
        </div>

        <div class="col-sm-4">
          <label>Perfil</label>
          <div class="form-group has-feedback">
              <select class="form-control" id="perfil" name="perfil">
                <?php if($_SESSION['dados']['perfil'] != 'Desenvolvedor') { ?>
                  <?php
                    switch ($dadosUsuario[5]) {
                      case 'Usuário':
                        echo "<option value='users' selected>Usuário</option>";
                        echo "<option value='sup' disabled>Suporte</option>";
                        echo "<option value='adm' disabled>Administrador</option>";
                        echo "<option value='adm_dev' disabled>Desenvolvedor</option>";
                        break;
                      case 'Suporte':
                        echo "<option value='users' disabled>Usuário</option>";
                        echo "<option value='sup' selected>Suporte</option>";
                        echo "<option value='adm' disabled>Administrador</option>";
                        echo "<option value='adm_dev' disabled>Desenvolvedor</option>";
                        break;
                      case 'Administrador':
                        echo "<option value='users' disabled>Usuário</option>";
                        echo "<option value='sup' disabled>Suporte</option>";
                        echo "<option value='adm' select>Administrador</option>";
                        echo "<option value='adm_dev' disabled>Desenvolvedor</option>";
                        break;
                      case 'Desenvolvedor':
                        echo "<option value='users' disabled>Usuário</option>";
                        echo "<option value='sup' disabled>Suporte</option>";
                        echo "<option value='adm' disabled>Administrador</option>";
                        echo "<option value='adm_dev' selected>Desenvolvedor</option>";
                        break;
                      default:

                        break;
                    } ?>
                  <?php }else if($_SESSION['dados']['perfil'] == 'Desenvolvedor') { ?>
                    <?php
                      switch ($dadosUsuario[5]) {
                        case 'Usuário':
                          echo "<option value='users' selected>Usuário</option>";
                          echo "<option value='sup'>Suporte</option>";
                          echo "<option value='adm'>Administrador</option>";
                          echo "<option value='adm_dev'>Desenvolvedor</option>";
                          break;
                        case 'Suporte':
                          echo "<option value='users'>Usuário</option>";
                          echo "<option value='sup' selected>Suporte</option>";
                          echo "<option value='adm'>Administrador</option>";
                          echo "<option value='adm_dev'>Desenvolvedor</option>";
                          break;
                        case 'Administrador':
                          echo "<option value='users'>Usuário</option>";
                          echo "<option value='sup'>Suporte</option>";
                          echo "<option value='adm' selected>Administrador</option>";
                          echo "<option value='adm_dev'>Desenvolvedor</option>";
                          break;
                        case 'Desenvolvedor':
                          echo "<option value='users'>Usuário</option>";
                          echo "<option value='sup'>Suporte</option>";
                          echo "<option value='adm'>Administrador</option>";
                          echo "<option value='adm_dev' selected>Desenvolvedor</option>";
                          break;
                        default:

                          break;
                      } ?>
                  <?php } ?>
              </select>
          </div>
        </div>

      </div>
      <div class="row">
        <div class="col-sm-8">
          <label>Email</label>
            <div class="form-group has-feedback">
              <input type="email" class="form-control" name="email" id="email" value="<?= $dadosUsuario[2] ?>" placeholder="Email">
              <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
            </div>
        </div>
        <div class="col-sm-4">
          <label>Apelido</label>
            <div class="form-group has-feedback">
              <input type="text" class="form-control" name="apelido" id="apelido" value="<?= $dadosUsuario[3]?>">
              <span class="glyphicon glyphicon-user form-control-feedback"></span>
            </div>
        </div>
      </div>
      <div class="row" id="fieldSenha">
        <div class="col-sm-6">
          <label>Senha</label>
          <div class="form-group has-feedback">
            <input type="password" class="form-control" name="senha" value="<?= $dadosUsuario[4] ?>" placeholder="Senha" required>
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
        </div>
        <div class="col-sm-6">
          <label>Repetir Senha</label>
          <div class="form-group has-feedback">
            <input type="password" class="form-control" name="repetirSenha" placeholder="Repetir senha">
            <span class="glyphicon glyphicon-log-in form-control-feedback"></span>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-xs-8">
          <div class="checkbox icheck">
            <!-- Usado para manter o butão fluando a direita -->
          </div>
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" class="btn btn-primary btn-block btn-flat">Editar</button>
        </div>
        <!-- /.col -->
      </div>
    </form>
    <!-- /.col sss-->
  </div>
  <!-- /.row -->
</div>
<script>
  let auxPerfil = document.getElementById('auxPerfil').value;
  let keySession = document.getElementById('keySession').value;
  let keyGet = document.getElementById('keyGet').value;

  if(keySession == keyGet) {
    document.getElementById('fieldSenha').style.display='block';
  }else if(keySession != keyGet) {
    document.getElementById('fieldSenha').style.display='none';
  }

  if(auxPerfil == 'Administrador' || auxPerfil == 'Desenvolvedor') {
    document.getElementById('aux').removeAttr("disabled");
  }else if(auxPerfil == 'Usuário' || auxPerfil == 'Suporte') {
    document.getElementById('aux').setAttribute("readonly", "readonly");
  }

</script>
