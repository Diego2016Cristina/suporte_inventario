<?php

  $cat = new WebserviceDAO;

?>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <form method="POST" id="cadWebservice" action="../controller/WebserviceCadastro.php">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Cadastro de tooling</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="row">
              <div class="col-sm-12">
                <label>Código/SAP</label>
                <div class="form-group has-feedback">
                  <input type="text" class="form-control" name="codigo" placeholder="Código" minlength="5" maxlength="30" required>
                  <span class="glyphicon glyphicon-barcode form-control-feedback"></span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-6">
                <label>Categoria</label>
                <div class="form-group has-feedback">
                  <select class="form-control" name="descricao">
                    <option>Selecione</option>
                    <?php $resul = $cat->doListarCat(); ?>
                  </select>
                </div>
              </div>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
          <button type="submit" name="cadastrar" class="btn btn-primary">Cadastrar</button>
        </div>
      </div>
      </form>
  </div>
</div>

<script>
$('#myModal').on('shown.bs.modal', function () {
  $('#myInput').trigger('focus')
})
</script>
