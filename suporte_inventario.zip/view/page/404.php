<section class="content">
  <div class="error-page">
    <h2 class="headline text-yellow"> 404</h2>

    <div class="error-content">
      <h3><i class="fa fa-warning text-yellow"></i> Oops! Página não encontrada.</h3>

      <p>
        Não foi possível encontrar a página que você estava procurando.
        Enquanto isso, você pode retornar a página principal ou tentar novamente.
      </p>
    </div>
    <!-- /.error-content -->
  </div>
  <!-- /.error-page -->
</section>
