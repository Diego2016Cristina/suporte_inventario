<?php
  session_start();

  if(!isset($_SESSION['apelidoUsuario'])) {
    header('location: ../logout.php');
  }
?>
<script type="text/javascript">//Ainda não está funcional, verificar isso + tarde.
    setTimeout(function() {
    $("#msn").fadeOut().empty();
  }, 5000);
</script>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Sistema de Inventário | BE</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="../assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Formatação -->
  <link rel="stylesheet" href="../assets/css/style_index.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../assets/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="../assets/bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../assets/dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../assets/dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="../../index2.html" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>F</b>S</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>FULL</b>STACK</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->

          <!-- Notifications: style can be found in dropdown.less -->

          <!-- Tasks: style can be found in dropdown.less -->

          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <span class="hidden-xs"><?= $_SESSION['dados']['nome'] ?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <div style="position: relative; padding: 20px"></div>

                <p>
                  <?= $_SESSION['dados']['apelido']; ?> - <strong><?= $_SESSION['dados']['perfil']; ?></strong>
                  <small>Membro desde <?php echo date("d", strtotime($_SESSION['dados']['dt_criacao'])); ?> de
                    <?php switch (date("m", strtotime($_SESSION['dados']['dt_criacao']))) {
                      case 1:
                        echo "Janeiro";
                        break;
                      case 2:
                        echo "Fereiro";
                        break;
                      case 3:
                        echo "Março";
                        break;
                      case 4:
                        echo "Abril";
                        break;
                      case 5:
                        echo "Maio";
                        break;
                      case 6:
                        echo "Junho";
                        break;
                      case 7:
                        echo "Julho";
                        break;
                      case 8:
                        echo "Agosto";
                        break;
                      case 9:
                        echo "Setembro";
                        break;
                      case 10:
                        echo "Outubro";
                        break;
                      case 11:
                        echo "Novembro";
                        break;
                      case 13:
                        echo "Dezembro";
                        break;
                      default:
                        echo "Data maluca!";
                        break;
                    } ?>
                     <?php echo date("Y", strtotime($_SESSION['dados']['dt_criacao'])); ?></small>
                </p>
              </li>
              <!-- Menu Body -->
              <li class="user-body">

                <!-- /.row -->
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="homeDashboard.php?p=4&matricula=<?= $_SESSION['dados']['matricula'] ?>" class="btn btn-default btn-flat">Ver/ Editar perfil</a>
                </div>
                <div class="pull-right">
                  <a href="../logout.php" onclick="if (confirm('Deseja abandonar o sistema?')) commentDelete(1); return false" class="btn btn-default btn-flat">Fechar sessão</a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  </header>

  <!-- =============================================== -->

  <!-- Left side column. contains the sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">

      </div>
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MENU PRINCIPAL</li>
        <li class="treeview">
        <?php
          switch ($_SESSION['dados']['perfil']) {
            case 'Usuário':
                include("menu/users.php");
              break;
            case 'Suporte':
                include("menu/sup.php");
              break;
            case 'Administrador':
                include("menu/admin.php");
              break;
              case 'Desenvolvedor':
                  include("menu/admin_dev.php");
                break;
            default:
                  include("../logout.php");
              break;
            }
          ?>
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- =============================================== -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Sistema de Inventariado Interno
        <small>Desenvolvido pela eqp. de suporte</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li>
          <?php
            switch ($_GET['p']) {
              case 1:
                echo "<a href='#'>Cadastro de novos usuários.</a>";
                break;
              case 2:
                echo "<a href='#'>Lista de usuários cadastrados.</a>";
                break;
              case 3:
                echo "<a href='#'>Cadatro de tooling</a>";
                break;
              case 4:
                echo "<a href='#'>Editar usuário</a>";
                break;
              case 5:
                echo "<a href='#'>Timeline</a>";
                break;
              case 9:
                echo "<a href='#'>Editar webservice</a>";
                break;
              default:
                echo "<a href='#'></a>";
                break;
            }
            ?>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box"><!-- Aqui seleciona o subtitulo de cada página -->
        <div class="box-header with-border">
          <h3 class="box-title">
            <?php
              switch ($_GET['p']) {
                case 1:
                  echo "Cadastro de novos usuários";
                  break;
                case 2:
                  echo "Lista de usuários cadastrados";
                  break;
                case 3:
                  echo "Cadastrar no WEBSERVICE";
                  break;
                case 4:
                  echo "Editar usuário";
                  break;
                case 5:
                  echo "Timeline";
                  break;
                case 9:
                  echo "Editar WEBSERVICE";
                  break;
                default:
                  // code...
                  break;
              }
             ?></h3>
          <?php
            // mensagem de erro caso as senhas não sejam iguais
            if(isset($_GET['erro'])) {
              echo '<div class="alert alert-danger">As senhas devem ser iguais!</div>';
            }
            // mensagem de erro caso o login escolhido já exista no banco de dados
            if(isset($_GET['repetido'])) {
              echo '<div class="alert alert-danger">Este Login já foi escolhido por outra pessoa!</div>';
            }

          ?>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
                    title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <div class="box-body">

          <?php //pages created.
              switch ($_GET['p']) {
                case 1:
                  require("page/cadastrarUsuario.php");
                break;
                case 2:
                  require("page/listaUsuario.php");
                break;
                case 3:
                  require("page/cadastroWebservice.php");
                break;
                case 4:
                  require("page/editarUsuario.php");
                break;
                case 5:
                  require("page/timeline.php");
                  break;
                case 6:
                  $_SESSION['key'] = 1;
                  require("../controller/ExcluirUsuario.php");
                  break;
                case 7:
                  $_SESSION['key'] = 1;
                  require("../controller/ExcluirWebservice.php");
                  break;
                case 8:
                  require("page/listaWebservice.php");
                  break;
                case 9:
                  require("page/editarWebservice.php");
                  break;
                case 10:
                  require("page/cadLinha.php");
                  break;
                default:
                  require("page/404.php");
                  break;
              }

          ?>

        </div>
        <!-- /.box-body -->
        <div class="box-footer">
          <?php echo date('d/m/Y h:m:s'); ?>
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; <?= date('Y') ?> <a href="">FullStack.ini</a>.</strong> Todos os
    direito reservados.
  </footer>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="../assets/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="../assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="../assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="../assets/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../assets/dist/js/demo.js"></script>
<script>
  $(document).ready(function () {
    $('.sidebar-menu').tree()
  })
</script>
</body>
</html>

<!-- TRAZER A CATEGORIA -->
<?php include ("page/modalCadastrarTooling.php"); ?>
