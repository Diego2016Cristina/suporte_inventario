<a href="#">
  <i class="fa fa-user" aria-hidden="true"></i> <span>Usuário</span>
  <span class="pull-right-container">
    <i class="fa fa-angle-left pull-right"></i>
  </span>
</a>
<ul class="treeview-menu">
  <li><a href="homeDashboard.php?p=1"><i class="fa fa-circle-o"></i> Cadastrar</a></li>
  <li><a href="homeDashboard.php?p=2"><i class="fa fa-circle-o"></i> Listar</a></li>
  <li><a href="homeDashboard.php?p=2"><i class="fa fa-circle-o"></i> Enviar notificações</a></li>
</ul>
<li class="treeview">
  <ul class="treeview-menu">
    <li><a href="../assets/layout/top-nav.html"><i class="fa fa-circle-o"></i> Top Navigation</a></li>
    <li><a href="../assets/layout/boxed.html"><i class="fa fa-circle-o"></i> Boxed</a></li>
    <li><a href="../assets/layout/fixed.html"><i class="fa fa-circle-o"></i> Fixed</a></li>
    <li><a href="../assets/layout/collapsed-sidebar.html"><i class="fa fa-circle-o"></i> Collapsed Sidebar</a></li>
  </ul>
</li>
<li class="treeview">
  <a href="#">
    <i class="fa fa-database" aria-hidden="true"></i>
    <span>Master List</span>
    <span class="pull-right-container">
      <i class="fa fa-angle-left pull-right"></i>
    </span>
  </a>
  <ul class="treeview-menu">
    <li><a href="homeDashboard.php?p=8"><i class="fa fa-circle-o"></i> Listar</a></li>
  </ul>
</li>
<li class="treeview">
  <a href="#">
    <i class="fa fa-bars" aria-hidden="true"></i>
    <span>Linha</span>
    <span class="pull-right-container">
      <i class="fa fa-angle-left pull-right"></i>
    </span>
  </a>
  <ul class="treeview-menu">
    <li><a href="homeDashboard.php?p=10"><i class="fa fa-circle-o"></i> Cadastrar</a></li>
    <li><a href="#"><i class="fa fa-circle-o"></i> Listar</a></li>
  </ul>
</li>
<li><a href="#"><i class="fa fa-book"></i> <span>Documentação</span></a></li>
<li class="header">Menu Extras</li>
<li>
  <a href="#">
    <i class="fa fa-bell" aria-hidden="true"></i> <span>Notificações</span>
    <span class="pull-right-container">
      <small class="label pull-right bg-yellow">1</small>
      <small class="label pull-right bg-green">16</small>
      <small class="label pull-right bg-red">0</small>
    </span>
  </a>
</li>
<li><a href="homeDashboard.php?p=5"><i class="fa fa-circle-o"></i> Timeline </a></li>
