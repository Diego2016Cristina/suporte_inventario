<?php

  include ('class/Connection.class.php');
  include ('class/UsuarioDAO.class.php');

  $usuario = new UsuarioDAO();

  $logout = $usuario->logout();

 ?>
