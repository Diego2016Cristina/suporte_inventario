<?php

  private $matricula;
  private $nome;
  private $email;
  private $apelido;
  private $senha;
  private $perfil;
  private $user_status;
  private $dt_criacao;
  private $dt_modificacao;

  function getMatricula() {
    return $this->matricula;
  }

  function getNome() {
    return $this->nome;
  }

  function getEmail() {
    return $this->email;
  }

  function getApelido() {
    return $this->apelido;
  }

  function getSenha() {
    return $this->senha;
  }

  function getPerfil() {
    return $this->perfil;
  }

  function getUser_status() {
    return $this->user_status;
  }

  function getDt_criacao() {
    return $this->dt_criacao;
  }

  function getDt_modificacao() {
    return $this->dt_modificacao;
  }

  function setMatricula($matricula) {
    $this->$matricula = $matricula;
  }

  function setNome($nome) {
    $this->nome = $nome;
  }

  function setEmail($email) {
    $this->email = $email;
  }

  function setApelido($apelido) {
    $this->apelido = $apelido;
  }

  function setSenha($senha) {
    $this->senha = $senha;
  }

  function setPerfil($perfil) {
    $this->perfil = $perfil;
  }

  function setUser_status($user_status) {
    $this->user_status = $user_status;
  }

  function setDt_criacao($dt_criacao) {
    $this->dt_criacao = $dt_criacao;
  }

  function setDt_modificacao($dt_modificacao) {
    $this->dt_modificacao = $dt_modificacao;
  }
