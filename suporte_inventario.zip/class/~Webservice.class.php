<?php

  private $codigo;
  private $descricao;
  private $dt_cadastro;
  private $status;

  function getCodigo() {
    return $this->codigo;
  }

  function getDescricao() {
    return $this->descricao;
  }

  function getDt_cadastro() {
    return $this->dt_cadastro;
  }

  function getStatus() {
    return $this->status;
  }

  function setCodigo($codigo) {
    $this->$codigo = $codigo;
  }

  function setDescricao($descricao) {
    $this->descricao = $descricao;
  }

  function setDt_cadastro($dt_cadastro) {
    $this->dt_cadastro = $dt_cadastro;
  }

  function setStatus($status) {
    $this->status = $status;
  }
