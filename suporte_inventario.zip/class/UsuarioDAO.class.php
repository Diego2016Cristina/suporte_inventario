<?php

  class UsuarioDAO {
    private $connection;

    public function __construct() {
      $this->connection = new Connection();
    }

    // efetua login
    public function login($apelido, $senha) {
      $sql = "SELECT * FROM usuario WHERE apelido = '$apelido' AND senha = '$senha'";

      $executa = mysqli_query($this->connection->getCon(), $sql);

      if(mysqli_num_rows($executa) > 0) {
        return true;
      } else {
        return false;
      }
    }

    public function doListarUsuario($inicio, $qnt_result_pg) {
      $sql = "SELECT u.matricula, u.nome, u.email, u.apelido, g.descricao AS 'perfil', u.dt_criacao FROM grupo_usuario gu INNER JOIN grupo g ON gu.grupo_id = g.id
              INNER JOIN usuario u ON gu.id_usuario = u.matricula WHERE u.matricula = gu.id_usuario ORDER BY u.nome ASC LIMIT $inicio, $qnt_result_pg";
      $result = mysqli_query($this->connection->getCon(), $sql);

      return $result;
    }

    public function doNumRows() {
      $sql = "SELECT * FROM usuario";
      $result = mysqli_query($this->connection->getCon(), $sql);

      return $result;
    }

    // Verifica se já existe login com o nome escolhido
    public function unico($apelido, $matricula) {

      $unic = "SELECT * FROM usuario WHERE apelido = '$apelido' OR matricula = '$matricula'";

      $exec = mysqli_query($this->connection->getCon(), $unic);

      if(mysqli_num_rows($exec) > 0) { // Se maior que 0, foi encontrado usuário
        return true;
      } else {
        return false;
      }
    }


    public function doUnico($matricula=NULL) {

      $unic = "SELECT u.matricula, u.nome, u.email, u.apelido, u.senha, g.descricao AS 'perfil' FROM grupo_usuario gu INNER JOIN grupo g ON gu.grupo_id = g.id
INNER JOIN usuario u ON gu.id_usuario = u.matricula WHERE u.matricula = '$matricula'";

      $executa = mysqli_query($this->connection->getCon(), $unic);

      if($fetch = mysqli_fetch_row($executa)) { // Se maior que 0, foi encontrado usuário
        return $fetch;
      } else {
        return false;
      }
    }

    // cadastra o usuário
    public function cadastra($matricula, $nome, $email, $apelido, $senha) {

      $sql = "INSERT INTO usuario (matricula, nome, email, apelido, senha) VALUES ('$matricula', '$nome', '$email',
        '$apelido','$senha')";

      $executa = mysqli_query($this->connection->getCon(), $sql);

      if(mysqli_affected_rows($this->connection->getCon()) > 0) {
        return true;
      } else {
        return false;
      }
    }

    public function doEditar($matricula, $nome, $email, $apelido, $perfil, $senha) {
      $sql = "UPDATE usuario
      INNER JOIN grupo_usuario ON grupo_usuario.id_usuario =  usuario.matricula
      SET usuario.nome = '$nome', usuario.email = '$email', usuario.apelido = '$apelido',
      usuario.senha = '$senha', grupo_usuario.grupo_id = $perfil WHERE usuario.matricula = '$matricula' LIMIT 1";

      $executa = mysqli_query($this->connection->getCon(), $sql);

      if(mysqli_affected_rows($this->connection->getCon()) > 0) {
        return true;
      }else {
        return false;
      }
    }

    public function doDelete($matricula = NULL) {
      $sql = "DELETE FROM usuario WHERE matricula = '$matricula'";

      $executa = mysqli_query($this->connection->getCon(), $sql);

      if(mysqli_affected_rows($this->connection->getCon()) > 0) {
        return true;
      }else {
        return false;
      }
    }

    # Usado para realizar o login;
    public function doDadosUsuarios($apelido) {
      $sql = "SELECT u.matricula, u.nome, u.email, u.apelido, g.descricao AS 'perfil', u.dt_criacao FROM grupo_usuario gu INNER JOIN grupo g ON gu.grupo_id = g.id
INNER JOIN usuario u ON gu.id_usuario = u.matricula WHERE u.apelido = '$apelido' ORDER BY nome ASC";
      $executa = mysqli_query($this->connection->getCon(), $sql);

      while($fetch = mysqli_fetch_row($executa)) {
        $resultado = array(
          'matricula' => $fetch[0],
          'nome'      => $fetch[1],
          'email'     => $fetch[2],
          'apelido'   => $fetch[3],
          'perfil'    => $fetch[4],
          'dt_criacao'=> $fetch[5]
        );

        return $resultado;
      }
    }

    public function doConsultaGrupo($perfil) {
      $sql = "SELECT id FROM grupo WHERE nome = '$perfil' LIMIT 1";

      $execute = mysqli_query($this->connection->getCon(), $sql);

      if($fetch = mysqli_fetch_row($execute)) {
        return $fetch[0];
      } else {
        echo "Erro ao buscar perfil. Entre em contato com a eqp de Desenvolvedor.";
      }
    }

    public function doCadGrupo($matricula, $id_grupo) {
      $sql = "INSERT INTO grupo_usuario (id_usuario, grupo_id) VALUES ('$matricula', '$id_grupo')";

      $executa = mysqli_query($this->connection->getCon(), $sql);

      if(mysqli_affected_rows($this->connection->getCon()) > 0) {
        return true;
      }else {
        return false;
      }
    }

//     public function doUsuario($matricula) {
//       $sql = "SELECT u.matricula, u.nome, u.email, u.apelido, g.descricao AS 'perfil', u.dt_criacao FROM grupo_usuario gu INNER JOIN grupo g ON gu.grupo_id = g.id
// INNER JOIN usuario u ON gu.id_usuario = u.matricula WHERE u.matricula = '$matricula' LIMIT 1";
//       $executa = mysqli_query($this->connection->getCon(), $sql);
//
//       while($fetch = mysqli_fetch_row($executa)) {
//         $resultado = array(
//           'matricula' => $fetch[0],
//           'nome'      => $fetch[1],
//           'email'     => $fetch[2],
//           'apelido'   => $fetch[3],
//           'perfil'    => $fetch[4],
//           'dt_criacao'=> $fetch[5]
//         );
//
//         echo "<pre>"; print_r($resultado); exit;
//       }
//     }

    // efetua logout
    public function logout() {

      session_start();

      session_destroy();

      //setcookie("login" , "" , time()-60*5);
      header("Location:view/login.php?logout");
      exit();
    }

  }
