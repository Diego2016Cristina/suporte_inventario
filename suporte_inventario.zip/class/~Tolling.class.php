<?php

private $codigo;
private $descricao;
private $estoque_min;
private $estoque_max;
private $dt_entrada;
private $tool_status;

function getCodigo() {
  return $this->codigo;
}

function getDescricao() {
  return $this->descricao;
}

function getEstoque_min() {
  return $this->estoque_min;
}

function getEstoque_max() {
  return $this->estoque_max;
}

function getDt_entrada() {
  return $this->dt_entrada;
}

function getTool_status() {
  return $this->tool_status;
}

function setCodigo($codigo) {
  $this->codigo = $codigo;
}

function setDescricao($descricao) {
  $this->descricao = $descricao;
}

function setEstoque_min($estoque_min) {
  $this->estoque_min = $estoque_min;
}

function setEstoque_max($estoque_max) {
  $this->estoque_max = $estoque_max;
}

function setDt_entrada($dt_entrada) {
  $this->dt_entrada = $dt_entrada;
}

function setTool_status($tool_status) {
  $this->tool_status = $tool_status;
}
