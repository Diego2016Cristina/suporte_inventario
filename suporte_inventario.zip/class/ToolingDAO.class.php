<?php

class ToolingDAO {
  private $connection;

  public function __construct() {
    $this->connection = new Connection();
  }

  # Verifica se o código já foi cadastrado.

  public function doUnico($codigo) {
    $sql = "SELECT * FROM tooling WHERE codigo = $codigo";

    $executa = mysqli_query($this->connection->getCon(), $sql);

    if(mysqli_num_rows($executa) > 0) {
      return false;
    }else {
      return true;
    }
  }

  # Cadastar tooling;
  public function doCadastrar($codigo, $descricao, $estoque_min, $estoque_max, $dt_entrada) {
    $sql = "INSERT INTO tooling (codigo, descricao, estoque_min, estoque_max, dt_entrada)
    VALUES ('$codigo', '$descricao', '$estoque_min', '$estoque_max', '$dt_entrada')";

    $executa = mysqli_query($this->connection->getCon(), $sql);

    if(mysqli_affected_rows($this->connection->getCon()) > 0) {
      return true;
    }else {
      return false;
    }
  }

}
