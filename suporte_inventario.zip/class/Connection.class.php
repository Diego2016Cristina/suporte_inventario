<?php
  class Connection {
    private $usuario = 'root';
    private $senha   = '';
    private $caminho = 'localhost';
    private $banco   = 'db_inventario_boreo';
    private $con;

    public function __construct() {
      $this->con = mysqli_connect($this->caminho, $this->usuario, $this->senha) or
      die("Conexão com o banco de dados falhou!" . mysqli_error($this->con));

      mysqli_select_db($this->con, $this->banco) or die("Conexão com o banco de dados falhou!". mysqli_error($this->com));

    }

    public function getCon() {
      return $this->con;
    }
  }
?>
