<?php
/**
 *
 */
class WebserviceDAO {
  private $connection;

  public function __construct() {
    $this->connection = new Connection;
  }

  // cadastra o usuário
  public function cadastra($codigo, $descricao) {

    $sql = "INSERT INTO webservice (codigo, descricao) VALUES ('$codigo', '$descricao')";

    $executa = mysqli_query($this->connection->getCon(), $sql);

    if(mysqli_affected_rows($this->connection->getCon()) > 0) {
      return true;
    } else {
      return false;
    }
  }

  public function doEditar($codigo, $descricao, $status_ws, $dt_modificacao) {
    $sql = "UPDATE webservice SET codigo = $codigo, descricao = '$descricao', status_ws = $status_ws, dt_modificacao = '$dt_modificacao' WHERE codigo = $codigo LIMIT 1;";

    $executa = mysqli_query($this->connection->getCon(), $sql);

    if(mysqli_affected_rows($this->connection->getCon()) > 0) {
      return true;
    }else {
      return false;
    }
  }

  public function doDelete($codigo = NULL) {
    $sql = "DELETE FROM webservice WHERE codigo = '$codigo'";

    $executa = mysqli_query($this->connection->getCon(), $sql);

    if(mysqli_affected_rows($this->connection->getCon()) > 0) {
      return true;
    }else {
      return false;
    }
  }

  public function doPesquisar($codigo) {
    $sql = "SELECT * FROM webservice WHERE codigo LIKE '%$codigo%'";
    $result = mysqli_query($this->connection->getCon(), $sql);

    return $result;

  }

  public function doBuscaUnica($codigo) {
    $sql = "SELECT * FROM webservice WHERE codigo LIKE '%$codigo%' LIMIT 1";
    $executa = mysqli_query($this->connection->getCon(), $sql);

    while($fetch = mysqli_fetch_row($executa)) {
      return $fetch;
    }

  }

  // Verifica se já existe login com o nome escolhido
  public function unico($codigo) {

    $unic = "SELECT * FROM webservice WHERE codigo = '$codigo'";

    $exec = mysqli_query($this->connection->getCon(), $unic);

    if(mysqli_num_rows($exec) > 0) { // Se maior que 0, foi encontrado usuário
      return true;
    } else {
      return false;
    }
  }

  public function doListarWeb($pesquisar, $inicio, $qnt_result_pg) {
    $n = $inicio;
    $sql = "SELECT * FROM webservice WHERE codigo LIKE '%$pesquisar%' ORDER BY codigo DESC LIMIT $inicio, $qnt_result_pg";
    $result = mysqli_query($this->connection->getCon(), $sql);

    return $result;
  }

  public function doNumRows($codigo) {
    $sql = "SELECT * FROM webservice WHERE codigo LIKE '%$codigo%'";
    $result = mysqli_query($this->connection->getCon(), $sql);

    return $result;
  }

  # Buscar categoria
  public function doListarCat() {
    $sql = "SELECT * FROM categoria";
    $result = mysqli_query($this->connection->getCon(), $sql);

    while ($fetch = mysqli_fetch_row($result)) {
      echo "<option value='$fetch[1]'>".$fetch[1]."</option>";
    }
  }
}
