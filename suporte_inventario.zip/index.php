<?php
  session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>Usando eventos no Javascript</title>
<!-- <script src="https://code.jquery.com/jquery-3.5.0.js"></script> -->
<link rel="stylesheet" href="assets/css/style_index.css?v=1">
</head>
<body>

  <div class="section">
    <div class="title_system">
      <p>Eqp. Suporte Teste (BE)</p>
      <span>Sistema de Inventário Interno</span>
    </div>
    <div class="img_button">
      <button type="button" id="button_img">
        <img src="assets/img/estoque.png">
        <span class="badge"> 0 </span>
      </button>
    </div>
  </section>
  <small>* Sistema desenvolvido pela eqp. de suporte(BE). Todos os direitos reservados</small>

<script>
  var contador = document.querySelector('.badge');

  document.querySelector('button').addEventListener('click', function(){
    var numero = parseInt(contador.textContent) + 1;
    contador.textContent = numero;
    if(numero == 3) {
      contador.textContent = 0;
      // Redireciona o usuário para a página da DevMedia após cinco segundos
      alert("Dentro de alguns instante você será redirecionado para outra página.");
      setTimeout(function() {
          window.location.href = "view/login.php";
      }, 1000);
    }

  });
</script>

</body>
</html>
<?php
# MATANDO A SESSION AO SAIR DA PÁGINA ATUAL;
unset($_SESSION['matricula']);
unset($_SESSION['nome']);
unset($_SESSION['email']);
unset($_SESSION['apelido']);
?>
